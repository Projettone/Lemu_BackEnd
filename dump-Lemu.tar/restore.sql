--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: aste_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aste_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: carrello; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carrello (
    id bigint NOT NULL,
    utente bigint,
    utente_id bigint
);


--
-- Name: carrello_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.carrello_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carrello_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.carrello_id_seq OWNED BY public.carrello.id;


--
-- Name: carrelloprodotti; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carrelloprodotti (
    id bigint NOT NULL,
    quantita integer NOT NULL,
    carrello bigint,
    prodotto bigint,
    carrello_id bigint,
    prodotto_id bigint
);


--
-- Name: carrelloprodotti_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.carrelloprodotti_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carrelloprodotti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.carrelloprodotti_id_seq OWNED BY public.carrelloprodotti.id;


--
-- Name: categoria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoria (
    id bigint NOT NULL,
    immagine character varying(255),
    nome character varying(255) NOT NULL
);


--
-- Name: categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categoria_id_seq OWNED BY public.categoria.id;


--
-- Name: images_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.images_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: immobili_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.immobili_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ordine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordine (
    id bigint NOT NULL,
    data_acquisto date,
    citta character varying(255),
    numero_civico integer,
    via character varying(255),
    prezzo_totale_ordine double precision,
    ordini bigint,
    acquirente bigint
);


--
-- Name: ordine_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ordine_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ordine_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ordine_id_seq OWNED BY public.ordine.id;


--
-- Name: ordine_prodotto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordine_prodotto (
    id bigint NOT NULL,
    "quantità" integer,
    id_ordine bigint,
    id_prodotto bigint
);


--
-- Name: ordine_prodotto_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ordine_prodotto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ordine_prodotto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ordine_prodotto_id_seq OWNED BY public.ordine_prodotto.id;


--
-- Name: prodotto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prodotto (
    id bigint NOT NULL,
    categoria character varying(255),
    descrizione character varying(255),
    disponibilita boolean,
    immagine_prodotto oid,
    nome character varying(255),
    prezzo real,
    venduti integer,
    utente bigint
);


--
-- Name: prodotto_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.prodotto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: prodotto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.prodotto_id_seq OWNED BY public.prodotto.id;


--
-- Name: recensione; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recensione (
    id bigint NOT NULL,
    commento character varying(255),
    rating real,
    autore bigint,
    prodotto bigint
);


--
-- Name: recensione_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recensione_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recensione_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recensione_id_seq OWNED BY public.recensione.id;


--
-- Name: recensioni_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recensioni_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utente; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.utente (
    id bigint NOT NULL,
    bannato boolean,
    cognome character varying(255),
    email character varying(255),
    password character varying(255),
    immagine_profilo oid,
    citta_utente character varying(255),
    numero_civico integer,
    via_utente character varying(255),
    admin boolean,
    nome character varying(255)
);


--
-- Name: utente_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.utente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.utente_id_seq OWNED BY public.utente.id;


--
-- Name: wishlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wishlist (
    id bigint NOT NULL,
    utente bigint,
    utente_id bigint
);


--
-- Name: wishlist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wishlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wishlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wishlist_id_seq OWNED BY public.wishlist.id;


--
-- Name: wishlistprodotti; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wishlistprodotti (
    id bigint NOT NULL,
    prodotto_id bigint,
    wishlist_id bigint
);


--
-- Name: wishlistprodotti_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wishlistprodotti_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wishlistprodotti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wishlistprodotti_id_seq OWNED BY public.wishlistprodotti.id;


--
-- Name: carrello id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrello ALTER COLUMN id SET DEFAULT nextval('public.carrello_id_seq'::regclass);


--
-- Name: carrelloprodotti id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrelloprodotti ALTER COLUMN id SET DEFAULT nextval('public.carrelloprodotti_id_seq'::regclass);


--
-- Name: categoria id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoria ALTER COLUMN id SET DEFAULT nextval('public.categoria_id_seq'::regclass);


--
-- Name: ordine id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine ALTER COLUMN id SET DEFAULT nextval('public.ordine_id_seq'::regclass);


--
-- Name: ordine_prodotto id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine_prodotto ALTER COLUMN id SET DEFAULT nextval('public.ordine_prodotto_id_seq'::regclass);


--
-- Name: prodotto id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prodotto ALTER COLUMN id SET DEFAULT nextval('public.prodotto_id_seq'::regclass);


--
-- Name: recensione id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recensione ALTER COLUMN id SET DEFAULT nextval('public.recensione_id_seq'::regclass);


--
-- Name: utente id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utente ALTER COLUMN id SET DEFAULT nextval('public.utente_id_seq'::regclass);


--
-- Name: wishlist id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist ALTER COLUMN id SET DEFAULT nextval('public.wishlist_id_seq'::regclass);


--
-- Name: wishlistprodotti id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlistprodotti ALTER COLUMN id SET DEFAULT nextval('public.wishlistprodotti_id_seq'::regclass);


--
-- Data for Name: carrello; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4943.dat

--
-- Data for Name: carrelloprodotti; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4945.dat

--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4947.dat

--
-- Data for Name: ordine; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4949.dat

--
-- Data for Name: ordine_prodotto; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4951.dat

--
-- Data for Name: prodotto; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4953.dat

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4955.dat

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4957.dat

--
-- Data for Name: wishlist; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4959.dat

--
-- Data for Name: wishlistprodotti; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/4961.dat

--
-- Name: aste_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aste_id', 31, true);


--
-- Name: carrello_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carrello_id_seq', 1, false);


--
-- Name: carrelloprodotti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carrelloprodotti_id_seq', 1, false);


--
-- Name: categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categoria_id_seq', 1, false);


--
-- Name: images_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.images_id', 25, true);


--
-- Name: immobili_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.immobili_id', 27, true);


--
-- Name: ordine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ordine_id_seq', 1, false);


--
-- Name: ordine_prodotto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ordine_prodotto_id_seq', 1, false);


--
-- Name: prodotto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.prodotto_id_seq', 1, false);


--
-- Name: recensione_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recensione_id_seq', 1, false);


--
-- Name: recensioni_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recensioni_id', 2, true);


--
-- Name: utente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.utente_id_seq', 4, true);


--
-- Name: wishlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wishlist_id_seq', 1, false);


--
-- Name: wishlistprodotti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wishlistprodotti_id_seq', 1, false);


--
-- Name: carrello carrello_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT carrello_pkey PRIMARY KEY (id);


--
-- Name: carrelloprodotti carrelloprodotti_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrelloprodotti
    ADD CONSTRAINT carrelloprodotti_pkey PRIMARY KEY (id);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id);


--
-- Name: ordine ordine_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT ordine_pkey PRIMARY KEY (id);


--
-- Name: ordine_prodotto ordine_prodotto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine_prodotto
    ADD CONSTRAINT ordine_prodotto_pkey PRIMARY KEY (id);


--
-- Name: prodotto prodotto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prodotto
    ADD CONSTRAINT prodotto_pkey PRIMARY KEY (id);


--
-- Name: recensione recensione_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_pkey PRIMARY KEY (id);


--
-- Name: carrello uk_1jsa62mhmgtj6ww7aftdkjpcb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT uk_1jsa62mhmgtj6ww7aftdkjpcb UNIQUE (utente);


--
-- Name: wishlist uk_2svb1lg1btqrk6a7yw81q9scj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT uk_2svb1lg1btqrk6a7yw81q9scj UNIQUE (utente);


--
-- Name: utente uk_gxvq4mjswnupehxnp35vawmo2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT uk_gxvq4mjswnupehxnp35vawmo2 UNIQUE (email);


--
-- Name: wishlist uk_ivtumes0k0mdw2m02337yb917; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT uk_ivtumes0k0mdw2m02337yb917 UNIQUE (utente_id);


--
-- Name: carrello uk_rx4nxhgb8yg9u6wu7lfxp4qjc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT uk_rx4nxhgb8yg9u6wu7lfxp4qjc UNIQUE (utente_id);


--
-- Name: utente utente_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pkey PRIMARY KEY (id);


--
-- Name: wishlist wishlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT wishlist_pkey PRIMARY KEY (id);


--
-- Name: wishlistprodotti wishlistprodotti_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlistprodotti
    ADD CONSTRAINT wishlistprodotti_pkey PRIMARY KEY (id);


--
-- Name: carrello fk2db8mu3vg5gjb438ygvfq6d2l; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT fk2db8mu3vg5gjb438ygvfq6d2l FOREIGN KEY (utente_id) REFERENCES public.utente(id);


--
-- Name: ordine_prodotto fk4vjw61obacst8xlbui1b7c1wr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine_prodotto
    ADD CONSTRAINT fk4vjw61obacst8xlbui1b7c1wr FOREIGN KEY (id_ordine) REFERENCES public.ordine(id);


--
-- Name: wishlistprodotti fk7u536836pmfktvofyolpn2jmo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlistprodotti
    ADD CONSTRAINT fk7u536836pmfktvofyolpn2jmo FOREIGN KEY (prodotto_id) REFERENCES public.prodotto(id);


--
-- Name: wishlist fk7u6axh54o8wmg3vxbg7tswyf8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT fk7u6axh54o8wmg3vxbg7tswyf8 FOREIGN KEY (utente) REFERENCES public.utente(id);


--
-- Name: carrelloprodotti fk8v2nlj2vt23rkc1s0u79ypsx5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrelloprodotti
    ADD CONSTRAINT fk8v2nlj2vt23rkc1s0u79ypsx5 FOREIGN KEY (prodotto_id) REFERENCES public.prodotto(id);


--
-- Name: prodotto fkbk3g3t8v04hco0s1p4di9l8uo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prodotto
    ADD CONSTRAINT fkbk3g3t8v04hco0s1p4di9l8uo FOREIGN KEY (utente) REFERENCES public.utente(id);


--
-- Name: recensione fkca461k82kbwirr4utlgm9tjou; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT fkca461k82kbwirr4utlgm9tjou FOREIGN KEY (autore) REFERENCES public.utente(id);


--
-- Name: recensione fkdoco4x696qad38ujcwu4gyiv6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT fkdoco4x696qad38ujcwu4gyiv6 FOREIGN KEY (prodotto) REFERENCES public.prodotto(id);


--
-- Name: ordine fkgf61gwevo6shdukma69pqvbuw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT fkgf61gwevo6shdukma69pqvbuw FOREIGN KEY (acquirente) REFERENCES public.utente(id);


--
-- Name: carrelloprodotti fkhcpfwoxsim9qpb0u7j9ncg561; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrelloprodotti
    ADD CONSTRAINT fkhcpfwoxsim9qpb0u7j9ncg561 FOREIGN KEY (carrello) REFERENCES public.carrello(id);


--
-- Name: wishlist fkilyabyqugyl0oxgvwp16l617v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT fkilyabyqugyl0oxgvwp16l617v FOREIGN KEY (utente_id) REFERENCES public.utente(id);


--
-- Name: wishlistprodotti fkjj2dskhboum7c9v3nvifmsg4v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlistprodotti
    ADD CONSTRAINT fkjj2dskhboum7c9v3nvifmsg4v FOREIGN KEY (wishlist_id) REFERENCES public.wishlist(id);


--
-- Name: ordine_prodotto fkk23p8l9ch84vpboxq53p4kiet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine_prodotto
    ADD CONSTRAINT fkk23p8l9ch84vpboxq53p4kiet FOREIGN KEY (id_prodotto) REFERENCES public.prodotto(id);


--
-- Name: carrelloprodotti fkmr5ery3q0ljxa577psjmhu1tj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrelloprodotti
    ADD CONSTRAINT fkmr5ery3q0ljxa577psjmhu1tj FOREIGN KEY (prodotto) REFERENCES public.prodotto(id);


--
-- Name: ordine fkq8xo97o9s7bf4374oyfj1w5e7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT fkq8xo97o9s7bf4374oyfj1w5e7 FOREIGN KEY (ordini) REFERENCES public.utente(id);


--
-- Name: carrello fkr1wn3b3ih79ucurf91lvr6h8o; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT fkr1wn3b3ih79ucurf91lvr6h8o FOREIGN KEY (utente) REFERENCES public.utente(id);


--
-- Name: carrelloprodotti fkt74tvd2n4xp61bqo0oga1q2yc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carrelloprodotti
    ADD CONSTRAINT fkt74tvd2n4xp61bqo0oga1q2yc FOREIGN KEY (carrello_id) REFERENCES public.carrello(id);


--
-- PostgreSQL database dump complete
--

